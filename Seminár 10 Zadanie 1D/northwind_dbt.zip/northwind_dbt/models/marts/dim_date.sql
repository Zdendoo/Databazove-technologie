SELECT to_char(d, 'YYYYMMDD')::int AS iddim_date,
       EXTRACT(day FROM d)::int     AS day,
       EXTRACT(isodow FROM d)::int  AS weekday,
       EXTRACT(year FROM d)::int    AS year,
       EXTRACT(week FROM d)::int    AS week,
       EXTRACT(month FROM d)::int   AS dim_month_iddim_month,
       EXTRACT(quarter FROM d)::int AS sdim_quarter_idsdim_quarter
FROM (SELECT DISTINCT order_date AS d
      FROM {{ ref('stg_orders') }}) x
