SELECT p.productid AS iddim_product,
       p.productname AS product_name,
       p.unit AS product_unit,
       p.supplierid AS sdim_supplier_idsdim_supplier,
       p.categoryid AS sdim_category_idsdim_category
FROM {{ ref('stg_products') }} p
