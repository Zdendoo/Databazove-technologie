SELECT q AS idsdim_quarter,
       q AS quarter,
       'Q' || q AS quarter_name
FROM generate_series(1, 4) AS q
