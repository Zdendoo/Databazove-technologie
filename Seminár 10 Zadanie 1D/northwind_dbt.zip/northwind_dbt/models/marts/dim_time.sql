SELECT EXTRACT(hour FROM t)::int * 10000
       + EXTRACT(minute FROM t)::int * 100
       + EXTRACT(second FROM t)::int AS iddim_time,
       EXTRACT(second FROM t)::int   AS second,
       EXTRACT(minute FROM t)::int   AS minute,
       EXTRACT(hour FROM t)::int     AS sdim_hour_idsdim_hour,
       CASE WHEN EXTRACT(hour FROM t) < 6  THEN 1
            WHEN EXTRACT(hour FROM t) < 12 THEN 2
            WHEN EXTRACT(hour FROM t) < 18 THEN 3
            ELSE 4 END               AS sdim_daypart_idsdim_daypart
FROM (SELECT DISTINCT order_time AS t
      FROM {{ ref('stg_orders') }}) x
