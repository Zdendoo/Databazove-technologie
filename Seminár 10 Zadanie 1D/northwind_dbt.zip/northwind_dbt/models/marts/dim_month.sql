SELECT m AS iddim_month,
       m AS month,
       to_char(make_date(2000, m, 1), 'FMMonth') AS month_name
FROM generate_series(1, 12) AS m
