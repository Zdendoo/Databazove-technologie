SELECT h AS idsdim_hour,
       h AS hour,
       CASE WHEN h % 12 = 0 THEN 12 ELSE h % 12 END AS hour_12,
       CASE WHEN h < 12 THEN 'AM' ELSE 'PM' END     AS am_pm
FROM generate_series(0, 23) AS h
