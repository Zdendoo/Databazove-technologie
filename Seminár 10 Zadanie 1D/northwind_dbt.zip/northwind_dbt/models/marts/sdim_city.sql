SELECT ROW_NUMBER() OVER (ORDER BY city)::int AS idsdim_city,
       city AS city_name
FROM (SELECT DISTINCT city
      FROM {{ ref('stg_customers') }}) x
