SELECT idsdim_daypart, part_of_day
FROM (VALUES (1, 'Night'),
             (2, 'Morning'),
             (3, 'Afternoon'),
             (4, 'Evening')) AS v(idsdim_daypart, part_of_day)
