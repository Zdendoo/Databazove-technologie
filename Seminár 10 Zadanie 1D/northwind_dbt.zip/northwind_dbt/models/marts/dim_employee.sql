SELECT employeeid AS iddim_employee,
       firstname AS first_name,
       lastname  AS last_name,
       birthdate::date AS birth_date
FROM {{ ref('stg_employees') }}
