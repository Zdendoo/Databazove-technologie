SELECT od.orderdetailid AS idfact_orders,
       p.price          AS product_price,
       od.quantity,
       od.quantity * p.price AS sales_amount,
       o.customerid     AS dim_customer_iddim_customer,
       o.employeeid     AS dim_employee_iddim_employee,
       o.shipperid      AS dim_shipper_iddim_shipper,
       od.productid     AS dim_product_iddim_product,
       to_char(o.order_date, 'YYYYMMDD')::int AS dim_date_iddim_date,
       EXTRACT(hour FROM o.order_time)::int * 10000
       + EXTRACT(minute FROM o.order_time)::int * 100
       + EXTRACT(second FROM o.order_time)::int AS dim_time_iddim_time
FROM {{ ref('stg_orderdetails') }} od
JOIN {{ ref('stg_orders') }}   o ON o.orderid   = od.orderid
JOIN {{ ref('stg_products') }} p ON p.productid = od.productid
