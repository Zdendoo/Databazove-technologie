SELECT c.customerid AS iddim_customer,
       c.customername AS customer_name,
       c.contactname  AS contact_name,
       c.address,
       ci.idsdim_city    AS sdim_city_idsdim_city,
       co.idsdim_country AS sdim_country_idsdim_country
FROM {{ ref('stg_customers') }} c
LEFT JOIN {{ ref('sdim_country') }} co ON co.country_name = c.country
LEFT JOIN {{ ref('sdim_city') }}    ci ON ci.city_name    = c.city
