SELECT categoryid AS idsdim_category,
       categoryname AS category_name
FROM {{ ref('stg_categories') }}
