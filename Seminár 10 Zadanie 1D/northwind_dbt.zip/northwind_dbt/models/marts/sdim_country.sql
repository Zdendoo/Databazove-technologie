SELECT ROW_NUMBER() OVER (ORDER BY country)::int AS idsdim_country,
       country AS country_name
FROM (SELECT DISTINCT country
      FROM {{ ref('stg_customers') }}) x
