SELECT shipperid AS iddim_shipper,
       shippername AS shipper_name
FROM {{ ref('stg_shippers') }}
