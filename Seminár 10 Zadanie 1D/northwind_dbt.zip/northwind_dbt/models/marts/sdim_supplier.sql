SELECT supplierid AS idsdim_supplier,
       suppliername AS supplier_name,
       contactname  AS contact_name,
       city,
       country
FROM {{ ref('stg_suppliers') }}
