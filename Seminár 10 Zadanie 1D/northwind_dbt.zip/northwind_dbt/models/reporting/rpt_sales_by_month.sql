SELECT d.year,
       d.dim_month_iddim_month AS month,
       m.month_name,
       COUNT(DISTINCT f.idfact_orders) AS order_lines,
       SUM(f.quantity)     AS total_quantity,
       SUM(f.sales_amount) AS total_sales
FROM {{ ref('fact_orders') }} f
JOIN {{ ref('dim_date') }}  d ON d.iddim_date  = f.dim_date_iddim_date
JOIN {{ ref('dim_month') }} m ON m.iddim_month = d.dim_month_iddim_month
GROUP BY d.year, d.dim_month_iddim_month, m.month_name
