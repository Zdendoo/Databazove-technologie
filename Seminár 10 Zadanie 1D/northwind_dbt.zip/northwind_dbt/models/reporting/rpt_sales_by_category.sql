SELECT c.category_name,
       SUM(f.quantity)     AS total_quantity,
       SUM(f.sales_amount) AS total_sales
FROM {{ ref('fact_orders') }} f
JOIN {{ ref('dim_product') }}  p ON p.iddim_product   = f.dim_product_iddim_product
JOIN {{ ref('sdim_category') }} c ON c.idsdim_category = p.sdim_category_idsdim_category
GROUP BY c.category_name
