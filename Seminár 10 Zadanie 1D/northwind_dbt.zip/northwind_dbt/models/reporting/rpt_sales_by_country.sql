SELECT co.country_name,
       COUNT(DISTINCT cu.iddim_customer) AS customers,
       SUM(f.sales_amount) AS total_sales
FROM {{ ref('fact_orders') }} f
JOIN {{ ref('dim_customer') }}  cu ON cu.iddim_customer   = f.dim_customer_iddim_customer
JOIN {{ ref('sdim_country') }}  co ON co.idsdim_country   = cu.sdim_country_idsdim_country
GROUP BY co.country_name
