SELECT productid, productname, supplierid, categoryid, unit, price
FROM {{ source('bronze', 'products') }}
