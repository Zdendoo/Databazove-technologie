SELECT orderdetailid, orderid, productid, quantity
FROM {{ source('bronze', 'orderdetails') }}
