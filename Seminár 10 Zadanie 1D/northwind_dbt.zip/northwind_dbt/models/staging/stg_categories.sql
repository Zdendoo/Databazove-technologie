SELECT categoryid, categoryname
FROM {{ source('bronze', 'categories') }}
