SELECT orderid, customerid, employeeid, shipperid,
       orderdate,
       orderdate::date AS order_date,
       orderdate::time AS order_time
FROM {{ source('bronze', 'orders') }}
