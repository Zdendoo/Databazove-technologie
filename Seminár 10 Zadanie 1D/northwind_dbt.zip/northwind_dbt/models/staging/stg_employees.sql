SELECT employeeid, firstname, lastname, birthdate
FROM {{ source('bronze', 'employees') }}
