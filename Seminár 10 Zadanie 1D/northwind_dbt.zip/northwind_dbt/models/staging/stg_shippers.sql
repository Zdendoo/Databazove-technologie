SELECT shipperid, shippername
FROM {{ source('bronze', 'shippers') }}
