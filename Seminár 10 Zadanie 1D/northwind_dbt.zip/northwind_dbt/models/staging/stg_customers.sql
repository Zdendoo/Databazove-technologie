SELECT customerid, customername, contactname, address, city, country
FROM {{ source('bronze', 'customers') }}
