SELECT supplierid, suppliername, contactname, city, country
FROM {{ source('bronze', 'suppliers') }}
