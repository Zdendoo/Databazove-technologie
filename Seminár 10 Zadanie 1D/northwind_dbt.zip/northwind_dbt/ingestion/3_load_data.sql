-- Spustite v psql z priečinka northwind_dbt/ (\copy číta súbory z vášho počítača).
-- Poradie stĺpcov v CSV musí zodpovedať tabuľkám z 2_create_bronze_tables.sql.
\copy bronze.categories   FROM 'ingestion/data/categories.csv'   WITH (FORMAT csv, HEADER true)
\copy bronze.customers    FROM 'ingestion/data/customers.csv'    WITH (FORMAT csv, HEADER true)
\copy bronze.employees    FROM 'ingestion/data/employees.csv'    WITH (FORMAT csv, HEADER true)
\copy bronze.shippers     FROM 'ingestion/data/shippers.csv'     WITH (FORMAT csv, HEADER true)
\copy bronze.suppliers    FROM 'ingestion/data/suppliers.csv'    WITH (FORMAT csv, HEADER true)
\copy bronze.products     FROM 'ingestion/data/products.csv'     WITH (FORMAT csv, HEADER true)
\copy bronze.orders       FROM 'ingestion/data/orders.csv'       WITH (FORMAT csv, HEADER true)
\copy bronze.orderdetails FROM 'ingestion/data/orderdetails.csv' WITH (FORMAT csv, HEADER true)
