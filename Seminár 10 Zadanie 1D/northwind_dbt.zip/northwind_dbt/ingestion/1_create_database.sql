-- Spustite pripojení na databázu postgres (nie na northwind_dbt)
CREATE DATABASE northwind_dbt;

-- Potom sa pripojte na northwind_dbt a vytvorte schémy
-- (silver, gold a reporting vytvorí dbt samo)
CREATE SCHEMA IF NOT EXISTS bronze;
