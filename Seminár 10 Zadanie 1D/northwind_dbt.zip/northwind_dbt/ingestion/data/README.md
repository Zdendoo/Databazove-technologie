Sem vložte zdrojové CSV súbory Northwind z kurzu (sekcia Dataset):
categories.csv, customers.csv, employees.csv, shippers.csv, suppliers.csv,
products.csv, orders.csv, orderdetails.csv
