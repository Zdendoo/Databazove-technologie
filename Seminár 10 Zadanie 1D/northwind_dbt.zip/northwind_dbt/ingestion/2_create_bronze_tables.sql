CREATE TABLE IF NOT EXISTS bronze.categories (
    categoryid   INT PRIMARY KEY,
    categoryname VARCHAR(100),
    description  VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS bronze.customers (
    customerid   INT PRIMARY KEY,
    customername VARCHAR(100),
    contactname  VARCHAR(100),
    address      VARCHAR(150),
    city         VARCHAR(100),
    postalcode   VARCHAR(30),
    country      VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS bronze.employees (
    employeeid INT PRIMARY KEY,
    lastname   VARCHAR(100),
    firstname  VARCHAR(100),
    birthdate  DATE,
    photo      VARCHAR(255),
    notes      TEXT
);

CREATE TABLE IF NOT EXISTS bronze.shippers (
    shipperid   INT PRIMARY KEY,
    shippername VARCHAR(100),
    phone       VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS bronze.suppliers (
    supplierid   INT PRIMARY KEY,
    suppliername VARCHAR(100),
    contactname  VARCHAR(100),
    address      VARCHAR(150),
    city         VARCHAR(100),
    postalcode   VARCHAR(30),
    country      VARCHAR(100),
    phone        VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS bronze.products (
    productid   INT PRIMARY KEY,
    productname VARCHAR(100),
    supplierid  INT,
    categoryid  INT,
    unit        VARCHAR(100),
    price       DECIMAL(10,2)
);

CREATE TABLE IF NOT EXISTS bronze.orders (
    orderid    INT PRIMARY KEY,
    customerid INT,
    employeeid INT,
    orderdate  TIMESTAMP,
    shipperid  INT
);

CREATE TABLE IF NOT EXISTS bronze.orderdetails (
    orderdetailid INT PRIMARY KEY,
    orderid       INT,
    productid     INT,
    quantity      INT
);
