SELECT r.id AS idfact_ratings,
       r.rating,
       r.userid AS dim_user_iddim_user,
       r.movieid AS dim_movie_iddim_movie,
       to_char(r.timestamp::date, 'YYYYMMDD')::int AS dim_date_iddim_date,
       EXTRACT(hour FROM r.timestamp::time)::int * 10000
       + EXTRACT(minute FROM r.timestamp::time)::int * 100
       + EXTRACT(second FROM r.timestamp::time)::int AS dim_time_iddim_time
FROM {{ ref('stg_ratings') }} r
