SELECT u.age_group,
       COUNT(*) AS ratings_count,
       ROUND(AVG(f.rating), 2) AS avg_rating
FROM {{ ref('fact_ratings') }} f
JOIN {{ ref('dim_user') }} u ON u.iddim_user = f.dim_user_iddim_user
GROUP BY u.age_group
