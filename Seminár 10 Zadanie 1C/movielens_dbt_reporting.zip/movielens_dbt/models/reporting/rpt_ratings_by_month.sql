SELECT d.month,
       d.month_name,
       COUNT(*) AS ratings_count,
       ROUND(AVG(f.rating), 2) AS avg_rating
FROM {{ ref('fact_ratings') }} f
JOIN {{ ref('dim_date') }} d ON d.iddim_date = f.dim_date_iddim_date
GROUP BY d.month, d.month_name
