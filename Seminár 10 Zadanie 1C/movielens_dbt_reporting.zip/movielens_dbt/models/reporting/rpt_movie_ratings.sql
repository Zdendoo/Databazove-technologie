SELECT m.title,
       m.releaseyear,
       m.genres,
       COUNT(*) AS ratings_count,
       ROUND(AVG(f.rating), 2) AS avg_rating
FROM {{ ref('fact_ratings') }} f
JOIN {{ ref('dim_movie') }} m ON m.iddim_movie = f.dim_movie_iddim_movie
GROUP BY m.title, m.releaseyear, m.genres
