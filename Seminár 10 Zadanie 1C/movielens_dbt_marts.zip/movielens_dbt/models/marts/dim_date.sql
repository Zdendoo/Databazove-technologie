SELECT to_char(d, 'YYYYMMDD')::int AS iddim_date,
       EXTRACT(day FROM d)::int     AS day,
       EXTRACT(isodow FROM d)::int  AS weekday,
       EXTRACT(year FROM d)::int    AS year,
       EXTRACT(week FROM d)::int    AS week,
       EXTRACT(month FROM d)::int   AS month,
       to_char(d, 'FMMonth')        AS month_name,
       EXTRACT(quarter FROM d)::int AS quarter
FROM (SELECT DISTINCT timestamp::date AS d
      FROM {{ ref('stg_ratings') }}) x
