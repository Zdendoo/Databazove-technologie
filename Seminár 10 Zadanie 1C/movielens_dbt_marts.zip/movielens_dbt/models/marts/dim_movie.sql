SELECT m.id AS iddim_movie,
       m.title,
       m.releaseyear,
       string_agg(g.name, ', ' ORDER BY g.name) AS genres
FROM {{ ref('stg_movies') }} m
JOIN {{ ref('stg_genres_movies') }} gm ON gm.movieid = m.id
JOIN {{ ref('stg_genres') }} g ON g.id = gm.genreid
GROUP BY m.id, m.title, m.releaseyear
