SELECT u.id AS iddim_user,
       u.gender,
       u.age,
       ag.name AS age_group,
       o.name AS occupation,
       u.zip_code
FROM {{ ref('stg_users') }} u
JOIN {{ ref('stg_age_group') }} ag ON ag.id = u.age
JOIN {{ ref('stg_occupations') }} o ON o.id = u.occupationid
