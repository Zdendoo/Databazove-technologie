SELECT EXTRACT(hour FROM t)::int * 10000
       + EXTRACT(minute FROM t)::int * 100
       + EXTRACT(second FROM t)::int AS iddim_time,
       EXTRACT(second FROM t)::int   AS second,
       EXTRACT(minute FROM t)::int   AS minute,
       EXTRACT(hour FROM t)::int     AS hour,
       CASE WHEN EXTRACT(hour FROM t) % 12 = 0 THEN 12
            ELSE EXTRACT(hour FROM t)::int % 12 END AS hour_12,
       CASE WHEN EXTRACT(hour FROM t) < 12 THEN 'AM' ELSE 'PM' END AS am_pm,
       CASE WHEN EXTRACT(hour FROM t) < 6  THEN 'Night'
            WHEN EXTRACT(hour FROM t) < 12 THEN 'Morning'
            WHEN EXTRACT(hour FROM t) < 18 THEN 'Afternoon'
            ELSE 'Evening' END AS part_of_day
FROM (SELECT DISTINCT timestamp::time AS t
      FROM {{ ref('stg_ratings') }}) x
