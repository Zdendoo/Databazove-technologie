SELECT id, userid, movieid, rating, timestamp
FROM {{ source('bronze', 'ratings') }}
