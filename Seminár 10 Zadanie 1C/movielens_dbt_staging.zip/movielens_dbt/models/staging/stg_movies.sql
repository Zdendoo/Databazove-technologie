SELECT id, title, releaseyear
FROM {{ source('bronze', 'movies') }}
