SELECT id, age, gender, occupationid, zip_code
FROM {{ source('bronze', 'users') }}
