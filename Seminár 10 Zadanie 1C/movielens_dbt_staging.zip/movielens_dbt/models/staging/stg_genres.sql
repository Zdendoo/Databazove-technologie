SELECT id, name
FROM {{ source('bronze', 'genres') }}
