SELECT id, movieid, genreid
FROM {{ source('bronze', 'genres_movies') }}
