SELECT id, name
FROM {{ source('bronze', 'age_group') }}
