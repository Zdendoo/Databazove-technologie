SELECT id, name
FROM {{ source('bronze', 'occupations') }}
